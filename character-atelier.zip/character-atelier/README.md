# Character Atelier

Character Atelier is a lightweight browser app for designing original characters. It runs as static files, with a small Node.js server for local hosting and an optional image-generation proxy.

## Run locally

```bash
npm start
```

Then open:

```text
http://localhost:3000
```

No npm dependencies are required.

## Optional image generation

Set `OPENAI_API_KEY` before starting the server:

```bash
OPENAI_API_KEY="your-key" npm start
```

The app checks `/api/health` and shows whether generation is available before enabling the Generate button. Without a key, prompt copy/export still works.

## Milestone 1: bootable app shell

Implemented:

- Minimal `index.html` entrypoint.
- Responsive dark UI with left workflow rail, center builder, and right preview rail.
- `package.json` with `npm start`, `npm dev`, and `npm run check`.
- Local Node static server.
- `/api/health` API-key status endpoint.
- Optional `/api/generate-image` endpoint using `gpt-image-2`.
- State initialization and local persistence through `localStorage`.
- Quick blueprint presets.
- Deep guided builder sections.
- Freeform keyword parsing.
- Live prompt generation.
- Markdown character sheet export.
- JSON import/export.

## Milestone 2: semantic reference workflow

Implemented:

- Batch image upload.
- Browser-local image reading with `FileReader`.
- Palette extraction with Canvas.
- Reference cards with user-confirmed semantic labels:
  - silhouette
  - build
  - palette
  - outfit
  - style
  - pose
  - mood
  - texture
- Per-reference observation notes.
- Per-reference strength setting.
- Originality guardrail field.
- Prompt integration through a reference transformation plan.

## Deployment

The included `vercel.json` routes the static app to `index.html` and keeps the serverless image endpoint at `api/generate-image.js`.
