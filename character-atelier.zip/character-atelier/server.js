import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT || 3000);
const PUBLIC_ROOT = __dirname;

const MIME_TYPES = new Map([
  [".html", "text/html; charset=utf-8"],
  [".css", "text/css; charset=utf-8"],
  [".js", "text/javascript; charset=utf-8"],
  [".json", "application/json; charset=utf-8"],
  [".md", "text/markdown; charset=utf-8"],
  [".svg", "image/svg+xml"],
  [".png", "image/png"],
  [".jpg", "image/jpeg"],
  [".jpeg", "image/jpeg"],
  [".webp", "image/webp"]
]);

function sendJson(res, statusCode, body) {
  res.writeHead(statusCode, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  });
  res.end(JSON.stringify(body));
}

function sendText(res, statusCode, text) {
  res.writeHead(statusCode, { "Content-Type": "text/plain; charset=utf-8" });
  res.end(text);
}

async function parseJsonBody(req) {
  const chunks = [];
  let size = 0;

  for await (const chunk of req) {
    size += chunk.length;
    if (size > 1_000_000) {
      throw Object.assign(new Error("Request body is too large."), { statusCode: 413 });
    }
    chunks.push(chunk);
  }

  if (!chunks.length) return {};

  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    throw Object.assign(new Error("Request body must be valid JSON."), { statusCode: 400 });
  }
}

function validateImageRequest(body) {
  const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
  const size = typeof body.size === "string" ? body.size : "1024x1024";
  const quality = typeof body.quality === "string" ? body.quality : "medium";
  const outputFormat = typeof body.outputFormat === "string" ? body.outputFormat : "png";

  const allowedSizes = new Set(["1024x1024", "1024x1536", "1536x1024", "auto"]);
  const allowedQuality = new Set(["low", "medium", "high", "auto"]);
  const allowedFormats = new Set(["png", "jpeg", "webp"]);

  if (!prompt) {
    throw Object.assign(new Error("Prompt is required."), { statusCode: 400 });
  }

  if (prompt.length > 8000) {
    throw Object.assign(new Error("Prompt must be 8000 characters or fewer."), { statusCode: 400 });
  }

  if (!allowedSizes.has(size)) {
    throw Object.assign(new Error("Unsupported image size."), { statusCode: 400 });
  }

  if (!allowedQuality.has(quality)) {
    throw Object.assign(new Error("Unsupported image quality."), { statusCode: 400 });
  }

  if (!allowedFormats.has(outputFormat)) {
    throw Object.assign(new Error("Unsupported output format."), { statusCode: 400 });
  }

  return { prompt, size, quality, outputFormat };
}

async function generateImage(req, res) {
  if (!process.env.OPENAI_API_KEY) {
    sendJson(res, 503, {
      ok: false,
      error: "OPENAI_API_KEY is not configured. Copy or export the prompt instead."
    });
    return;
  }

  try {
    const body = await parseJsonBody(req);
    const { prompt, size, quality, outputFormat } = validateImageRequest(body);

    const response = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-image-2",
        prompt,
        size,
        quality,
        output_format: outputFormat
      })
    });

    const payload = await response.json().catch(() => ({}));

    if (!response.ok) {
      sendJson(res, response.status, {
        ok: false,
        error: payload?.error?.message || "Image generation failed."
      });
      return;
    }

    const b64 = payload?.data?.[0]?.b64_json;
    if (!b64) {
      sendJson(res, 502, { ok: false, error: "Image response did not include image data." });
      return;
    }

    sendJson(res, 200, {
      ok: true,
      image: `data:image/${outputFormat};base64,${b64}`
    });
  } catch (error) {
    sendJson(res, error.statusCode || 500, {
      ok: false,
      error: error.message || "Unexpected image-generation error."
    });
  }
}

async function serveStatic(req, res) {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  let pathname = decodeURIComponent(url.pathname);

  if (pathname === "/") pathname = "/index.html";

  const requestedPath = path.normalize(path.join(PUBLIC_ROOT, pathname));
  if (!requestedPath.startsWith(PUBLIC_ROOT)) {
    sendText(res, 403, "Forbidden");
    return;
  }

  const filePath = existsSync(requestedPath) ? requestedPath : path.join(PUBLIC_ROOT, "index.html");
  const extension = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES.get(extension) || "application/octet-stream";

  try {
    const file = await readFile(filePath);
    res.writeHead(200, {
      "Content-Type": contentType,
      "Cache-Control": extension === ".html" ? "no-store" : "public, max-age=300"
    });
    res.end(file);
  } catch {
    sendText(res, 404, "Not found");
  }
}

const server = createServer(async (req, res) => {
  const url = new URL(req.url || "/", `http://${req.headers.host || "localhost"}`);

  if (url.pathname === "/api/health") {
    sendJson(res, 200, {
      ok: true,
      imageGenerationAvailable: Boolean(process.env.OPENAI_API_KEY),
      model: "gpt-image-2"
    });
    return;
  }

  if (url.pathname === "/api/generate-image") {
    if (req.method !== "POST") {
      sendJson(res, 405, { ok: false, error: "Method not allowed." });
      return;
    }
    await generateImage(req, res);
    return;
  }

  if (req.method !== "GET" && req.method !== "HEAD") {
    sendJson(res, 405, { ok: false, error: "Method not allowed." });
    return;
  }

  await serveStatic(req, res);
});

server.listen(PORT, () => {
  console.log(`Character Atelier running at http://localhost:${PORT}`);
  console.log(
    process.env.OPENAI_API_KEY
      ? "Image generation endpoint is enabled."
      : "Image generation endpoint is disabled until OPENAI_API_KEY is set."
  );
});
