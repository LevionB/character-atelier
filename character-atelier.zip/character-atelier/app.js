const STORAGE_KEY = "character-atelier-state-v2";

const DATA = {
  nav: [
    { id: "quick", icon: "⚡", label: "Quick Start" },
    { id: "deep", icon: "🧭", label: "Deep Builder" },
    { id: "freeform", icon: "✍", label: "Freeform" },
    { id: "references", icon: "🖼", label: "References" },
    { id: "prompt", icon: "🧪", label: "Prompt Lab" },
    { id: "sheet", icon: "📄", label: "Sheet Export" }
  ],
  species: ["Human", "Elf", "Orc", "Dragonkin", "Android", "Spirit", "Beastfolk", "Custom"],
  builds: ["slender", "athletic", "broad", "compact", "towering", "soft", "wiry", "imposing"],
  archetypes: ["wanderer", "royal", "outlaw", "scholar", "guardian", "performer", "inventor", "hunter"],
  settings: ["fantasy kingdom", "cyberpunk city", "space frontier", "modern occult", "post-collapse desert", "mythic forest", "academy", "undersea realm"],
  personalities: ["calm", "reckless", "witty", "stoic", "curious", "haunted", "warm", "ruthless", "idealistic", "secretive"],
  flaws: ["overprotective", "impatient", "vain", "avoidant", "vengeful", "gullible", "controlling", "self-sacrificing"],
  styles: ["cinematic concept art", "graphic novel", "anime key art", "painterly fantasy", "fashion editorial", "tabletop miniature reference", "clean animation model sheet"],
  clothing: ["long coat", "layered robes", "utility harness", "armored jacket", "ceremonial cloak", "streetwear", "battle dress", "travel gear"],
  materials: ["brushed steel", "weathered leather", "silk", "bone", "obsidian", "glowing glass", "denim", "fur trim"],
  accessories: ["nose ring", "visor", "satchel", "amulet", "utility belt", "mask", "tattoos", "weapon/tool"],
  referenceUses: ["silhouette", "build", "palette", "outfit", "style", "pose", "mood", "texture"]
};

const BLUEPRINTS = [
  {
    id: "urban-myth",
    title: "Urban Myth Hunter",
    description: "A practical occult investigator with street-level details and a supernatural hook.",
    patch: {
      identity: { archetype: "hunter", role: "Occult field investigator" },
      world: { setting: "modern occult", faction: "Unlicensed myth bureau" },
      wardrobe: { clothing: ["long coat", "utility harness"], materials: ["weathered leather"], accessories: ["amulet", "tattoos"] },
      personality: { traits: ["calm", "secretive"], flaws: ["avoidant"] },
      style: { artStyle: "cinematic concept art", mood: "rainy neon noir" }
    }
  },
  {
    id: "star-courier",
    title: "Star Courier",
    description: "A fast-talking interstellar runner with bright tech, layered gear, and hidden cargo.",
    patch: {
      identity: { archetype: "wanderer", role: "Interstellar courier" },
      body: { build: "wiry" },
      world: { setting: "space frontier", faction: "Independent courier guild" },
      wardrobe: { clothing: ["utility harness", "armored jacket"], materials: ["brushed steel", "glowing glass"], accessories: ["visor", "satchel"] },
      personality: { traits: ["witty", "reckless"], flaws: ["impatient"] },
      style: { artStyle: "clean animation model sheet", mood: "bright, kinetic, optimistic" }
    }
  },
  {
    id: "thorn-regent",
    title: "Thorn Regent",
    description: "A regal forest ruler with symbolic costume language and dangerous elegance.",
    patch: {
      identity: { archetype: "royal", role: "Exiled forest regent" },
      species: { type: "Elf", anatomy: "antler-like crown growths, pointed ears" },
      world: { setting: "mythic forest", faction: "Court of briars" },
      wardrobe: { clothing: ["layered robes", "ceremonial cloak"], materials: ["silk", "obsidian"], accessories: ["amulet"] },
      personality: { traits: ["stoic", "ruthless"], flaws: ["controlling"] },
      style: { artStyle: "painterly fantasy", mood: "elegant, dangerous, sacred" }
    }
  }
];

const DEFAULT_STATE = {
  mode: "quick",
  imageStatus: "idle",
  generatedImage: "",
  generatedError: "",
  api: {
    checked: false,
    imageGenerationAvailable: false,
    model: "gpt-image-2"
  },
  identity: {
    name: "Unnamed Character",
    pronouns: "they/them",
    age: "adult",
    archetype: "wanderer",
    role: "Independent adventurer",
    oneLine: "A striking original character with a clear visual hook."
  },
  body: {
    build: "athletic",
    height: "average height",
    face: "expressive eyes, distinct profile",
    marks: "",
    posture: "alert, balanced stance"
  },
  species: {
    type: "Human",
    anatomy: "standard humanoid anatomy",
    distinctness: "recognizable silhouette, cohesive proportions"
  },
  wardrobe: {
    clothing: ["travel gear"],
    materials: ["weathered leather"],
    accessories: ["satchel"],
    colorNotes: "balanced palette with one accent color"
  },
  world: {
    setting: "fantasy kingdom",
    faction: "No fixed faction",
    occupation: "traveler",
    stakes: "searching for a lost truth"
  },
  personality: {
    traits: ["curious", "calm"],
    flaws: ["avoidant"],
    habits: "notices small details before speaking",
    voice: "measured, observant, dry humor"
  },
  story: {
    origin: "Left home after discovering a secret that changed their future.",
    goal: "Find the source of the mystery before rivals do.",
    conflict: "They distrust help even when they need it.",
    relationships: "A former mentor, a rival, and one unlikely ally."
  },
  style: {
    artStyle: "cinematic concept art",
    mood: "dramatic but grounded",
    camera: "three-quarter full-body view",
    generator: "GPT Image",
    originality: "Transform inspirations into an original design; avoid direct copying."
  },
  references: [],
  freeform: "",
  promptOptions: {
    size: "1024x1024",
    quality: "medium",
    outputFormat: "png"
  }
};

const app = document.querySelector("#app");
let state = loadState();
let bound = false;

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function mergeDeep(target, source) {
  const output = Array.isArray(target) ? [...target] : { ...target };
  Object.entries(source || {}).forEach(([key, value]) => {
    if (value && typeof value === "object" && !Array.isArray(value)) {
      output[key] = mergeDeep(output[key] || {}, value);
    } else {
      output[key] = Array.isArray(value) ? [...value] : value;
    }
  });
  return output;
}

function loadState() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? mergeDeep(clone(DEFAULT_STATE), JSON.parse(saved)) : clone(DEFAULT_STATE);
  } catch {
    return clone(DEFAULT_STATE);
  }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function getPath(path) {
  return path.split(".").reduce((acc, key) => (acc ? acc[key] : undefined), state);
}

function setPath(path, value) {
  const parts = path.split(".");
  let target = state;
  parts.slice(0, -1).forEach((part) => {
    target[part] = target[part] || {};
    target = target[part];
  });
  target[parts.at(-1)] = value;
  saveState();
  render();
}

function escapeHtml(value = "") {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function uid() {
  return crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function list(values) {
  return values?.filter(Boolean).join(", ") || "Not set";
}

function render() {
  app.innerHTML = `
    <div class="app-shell">
      ${renderRail()}
      <main class="workspace">
        ${renderTopbar()}
        <section class="mode-panel">${renderModePanel()}</section>
      </main>
      ${renderPreview()}
    </div>
  `;

  if (!bound) {
    document.addEventListener("input", handleInput);
    document.addEventListener("change", handleChange);
    document.addEventListener("click", handleClick);
    bound = true;
  }
}

function renderRail() {
  return `
    <aside class="rail" aria-label="Workflow navigation">
      <div class="brand">
        <div class="brand-mark">CA</div>
        <div>
          <p class="brand-title">Character Atelier</p>
          <p class="brand-subtitle">Blueprint, mix, prompt, export.</p>
        </div>
      </div>

      <div class="nav-group">
        <p class="nav-label">Workflow</p>
        ${DATA.nav
          .map(
            (item) => `
              <button class="nav-button ${state.mode === item.id ? "active" : ""}" data-action="set-mode" data-mode="${item.id}">
                <span class="nav-icon">${item.icon}</span>
                <span>${item.label}</span>
              </button>
            `
          )
          .join("")}
      </div>

      <div class="nav-group">
        <p class="nav-label">Project actions</p>
        <div class="rail-actions">
          <button class="action-button" data-action="surprise">Surprise me</button>
          <button class="action-button" data-action="copy-prompt">Copy prompt</button>
          <button class="action-button" data-action="export-json">Export JSON</button>
          <label class="action-button file-control">
            Import JSON
            <input type="file" accept="application/json,.json" data-action="import-json" />
          </label>
          <button class="danger-button" data-action="reset">Reset design</button>
        </div>
      </div>
    </aside>
  `;
}

function renderTopbar() {
  const apiClass = state.api.checked
    ? state.api.imageGenerationAvailable
      ? "success"
      : "warning"
    : "";
  const apiLabel = state.api.checked
    ? state.api.imageGenerationAvailable
      ? "Generation enabled"
      : "Prompt export only"
    : "Checking API";

  return `
    <header class="topbar">
      <div>
        <p class="eyebrow">Original character design system</p>
        <h1>${escapeHtml(state.identity.name || "Unnamed Character")}</h1>
        <p>${escapeHtml(state.identity.oneLine)}</p>
      </div>
      <div class="topbar-card">
        <p class="field-label">Runtime</p>
        <div class="status-row">
          <span class="status-pill ${apiClass}">${apiLabel}</span>
        </div>
        <p class="help-text">Model target: ${escapeHtml(state.api.model || "gpt-image-2")}</p>
      </div>
    </header>
  `;
}

function renderModePanel() {
  const panels = {
    quick: renderQuickPanel,
    deep: renderDeepPanel,
    freeform: renderFreeformPanel,
    references: renderReferencePanel,
    prompt: renderPromptPanel,
    sheet: renderSheetPanel
  };
  return panels[state.mode]?.() || renderQuickPanel();
}

function renderQuickPanel() {
  return `
    <div class="panel">
      <div>
        <p class="section-kicker">Milestone 1</p>
        <h2>Fast blueprint</h2>
        <p class="panel-copy">Choose a preset, then adjust the core identity fields. The live preview updates immediately and persists locally.</p>
      </div>
      <div class="card-grid">
        ${BLUEPRINTS.map(
          (blueprint) => `
            <button class="card" data-action="apply-blueprint" data-blueprint="${blueprint.id}">
              <strong>${escapeHtml(blueprint.title)}</strong>
              <span>${escapeHtml(blueprint.description)}</span>
            </button>
          `
        ).join("")}
      </div>
      ${renderIdentitySection()}
      ${renderStyleSection()}
    </div>
  `;
}

function renderDeepPanel() {
  return `
    <div class="panel">
      <div>
        <p class="section-kicker">Guided workflow</p>
        <h2>Deep builder</h2>
        <p class="panel-copy">Build the design from identity through story, wardrobe, world, and image style.</p>
      </div>
      ${renderIdentitySection()}
      ${renderBodySection()}
      ${renderSpeciesSection()}
      ${renderWardrobeSection()}
      ${renderWorldSection()}
      ${renderPersonalitySection()}
      ${renderStorySection()}
      ${renderStyleSection()}
    </div>
  `;
}

function renderFreeformPanel() {
  return `
    <div class="panel">
      <div>
        <p class="section-kicker">Idea intake</p>
        <h2>Freeform parser</h2>
        <p class="panel-copy">Paste rough notes, then let the keyword parser map obvious details into the character state.</p>
      </div>
      <div class="section">
        <div class="field">
          <label class="field-label" for="freeform">Raw idea</label>
          <textarea id="freeform" data-path="freeform" placeholder="Example: A cyberpunk dragonkin courier with a neon visor, compact build, reckless personality, and worn leather jacket.">${escapeHtml(state.freeform)}</textarea>
        </div>
        <div class="output-actions" style="margin-top: 14px;">
          <button class="primary-button" data-action="parse-freeform">Parse into design</button>
          <button class="ghost-button" data-action="expand-freeform">Expand current brief</button>
        </div>
      </div>
    </div>
  `;
}

function renderReferencePanel() {
  return `
    <div class="panel">
      <div>
        <p class="section-kicker">Milestone 2</p>
        <h2>Semantic reference workflow</h2>
        <p class="panel-copy">Upload image references, extract local palettes, then label exactly what each image should contribute: silhouette, outfit, palette, style, pose, mood, or texture.</p>
      </div>

      <div class="section">
        <div class="section-header">
          <div>
            <h3>Add references</h3>
            <p>Files stay in the browser through data URLs and localStorage. No semantic analysis is assumed; labels are user-confirmed.</p>
          </div>
          <label class="primary-button file-control">
            Upload images
            <input type="file" accept="image/*" multiple data-action="upload-references" />
          </label>
        </div>
        ${state.references.length ? renderReferenceCards() : `<div class="notice">No references yet. Upload images to start semantic labeling.</div>`}
      </div>
    </div>
  `;
}

function renderPromptPanel() {
  return `
    <div class="panel">
      <div>
        <p class="section-kicker">Generator output</p>
        <h2>Prompt lab</h2>
        <p class="panel-copy">Review the generated prompt, copy it, or send it to the optional local image endpoint.</p>
      </div>
      <div class="section">
        <div class="field-grid">
          ${selectField("promptOptions.size", "Image size", ["1024x1024", "1024x1536", "1536x1024", "auto"])}
          ${selectField("promptOptions.quality", "Quality", ["low", "medium", "high", "auto"])}
          ${selectField("promptOptions.outputFormat", "Output format", ["png", "jpeg", "webp"])}
        </div>
        <div class="output-actions" style="margin-top: 14px;">
          <button class="action-button" data-action="copy-prompt">Copy prompt</button>
          <button class="primary-button" data-action="generate-image" ${state.api.imageGenerationAvailable ? "" : "disabled"}>Generate image</button>
        </div>
        <p class="help-text">${state.api.imageGenerationAvailable ? "Generation endpoint is available." : "Generation endpoint is unavailable until OPENAI_API_KEY is configured. Prompt export still works."}</p>
        ${state.imageStatus === "loading" ? `<p class="warning-text">Generating image…</p>` : ""}
        ${state.generatedError ? `<p class="error-text">${escapeHtml(state.generatedError)}</p>` : ""}
        ${state.generatedImage ? `<img class="generated-image" src="${state.generatedImage}" alt="Generated character concept" />` : ""}
      </div>
      <div class="output-card prompt-box">${escapeHtml(buildPrompt())}</div>
    </div>
  `;
}

function renderSheetPanel() {
  return `
    <div class="panel">
      <div>
        <p class="section-kicker">Export</p>
        <h2>Markdown character sheet</h2>
        <p class="panel-copy">Copy or download a generator-ready Markdown sheet for notes, tabletop use, or art direction.</p>
      </div>
      <div class="output-actions">
        <button class="action-button" data-action="copy-sheet">Copy sheet</button>
        <button class="action-button" data-action="download-sheet">Download .md</button>
      </div>
      <div class="markdown-box">${escapeHtml(buildSheet())}</div>
    </div>
  `;
}

function inputField(path, label, placeholder = "") {
  return `
    <div class="field">
      <label class="field-label" for="${path}">${label}</label>
      <input id="${path}" data-path="${path}" value="${escapeHtml(getPath(path) || "")}" placeholder="${escapeHtml(placeholder)}" />
    </div>
  `;
}

function textField(path, label, placeholder = "") {
  return `
    <div class="field">
      <label class="field-label" for="${path}">${label}</label>
      <textarea id="${path}" data-path="${path}" placeholder="${escapeHtml(placeholder)}">${escapeHtml(getPath(path) || "")}</textarea>
    </div>
  `;
}

function selectField(path, label, options) {
  const value = getPath(path);
  return `
    <div class="field">
      <label class="field-label" for="${path}">${label}</label>
      <select id="${path}" data-path="${path}">
        ${options
          .map((option) => `<option value="${escapeHtml(option)}" ${option === value ? "selected" : ""}>${escapeHtml(option)}</option>`)
          .join("")}
      </select>
    </div>
  `;
}

function chipSelector(path, label, options, multiple = false) {
  const value = getPath(path);
  const selected = multiple ? new Set(value || []) : new Set([value]);
  return `
    <div class="field">
      <span class="field-label">${label}</span>
      <div class="chip-row">
        ${options
          .map(
            (option) => `
              <button class="chip ${selected.has(option) ? "active" : ""}" data-action="chip" data-path="${path}" data-value="${escapeHtml(option)}" data-multiple="${multiple}">
                ${escapeHtml(option)}
              </button>
            `
          )
          .join("")}
      </div>
    </div>
  `;
}

function renderIdentitySection() {
  return `
    <section class="section">
      <div class="section-header">
        <div>
          <h3>Identity</h3>
          <p>Name, role, and the immediate promise of the character.</p>
        </div>
      </div>
      <div class="field-grid">
        ${inputField("identity.name", "Name", "Character name")}
        ${inputField("identity.pronouns", "Pronouns", "they/them")}
        ${inputField("identity.age", "Age impression", "adult")}
        ${inputField("identity.role", "Role", "exiled knight, courier, oracle")}
      </div>
      <div style="margin-top: 16px;">${chipSelector("identity.archetype", "Archetype", DATA.archetypes)}</div>
      <div style="margin-top: 16px;">${textField("identity.oneLine", "One-line brief")}</div>
    </section>
  `;
}

function renderBodySection() {
  return `
    <section class="section">
      <div class="section-header"><div><h3>Body and silhouette</h3><p>Define the readable shape language before adding details.</p></div></div>
      <div class="field-grid">
        ${inputField("body.height", "Height")}
        ${inputField("body.face", "Face")}
        ${inputField("body.marks", "Marks / tattoos / scars")}
        ${inputField("body.posture", "Posture")}
      </div>
      <div style="margin-top: 16px;">${chipSelector("body.build", "Build", DATA.builds)}</div>
    </section>
  `;
}

function renderSpeciesSection() {
  return `
    <section class="section">
      <div class="section-header"><div><h3>Species and anatomy</h3><p>Keep anatomy clear enough for the image prompt to follow.</p></div></div>
      <div class="field-grid">
        ${selectField("species.type", "Species", DATA.species)}
        ${inputField("species.anatomy", "Anatomy notes")}
        ${inputField("species.distinctness", "Distinctness rule")}
      </div>
    </section>
  `;
}

function renderWardrobeSection() {
  return `
    <section class="section">
      <div class="section-header"><div><h3>Wardrobe</h3><p>Use clothing, material, and accessory chips as prompt anchors.</p></div></div>
      ${chipSelector("wardrobe.clothing", "Clothing", DATA.clothing, true)}
      <div style="margin-top: 16px;">${chipSelector("wardrobe.materials", "Materials", DATA.materials, true)}</div>
      <div style="margin-top: 16px;">${chipSelector("wardrobe.accessories", "Accessories", DATA.accessories, true)}</div>
      <div style="margin-top: 16px;">${inputField("wardrobe.colorNotes", "Color notes")}</div>
    </section>
  `;
}

function renderWorldSection() {
  return `
    <section class="section">
      <div class="section-header"><div><h3>World</h3><p>Context gives costume and pose a reason to exist.</p></div></div>
      <div class="field-grid">
        ${selectField("world.setting", "Setting", DATA.settings)}
        ${inputField("world.faction", "Faction")}
        ${inputField("world.occupation", "Occupation")}
        ${inputField("world.stakes", "Stakes")}
      </div>
    </section>
  `;
}

function renderPersonalitySection() {
  return `
    <section class="section">
      <div class="section-header"><div><h3>Personality</h3><p>Personality becomes expression, posture, and detail priority.</p></div></div>
      ${chipSelector("personality.traits", "Traits", DATA.personalities, true)}
      <div style="margin-top: 16px;">${chipSelector("personality.flaws", "Flaws", DATA.flaws, true)}</div>
      <div class="field-grid" style="margin-top: 16px;">
        ${inputField("personality.habits", "Habits")}
        ${inputField("personality.voice", "Voice")}
      </div>
    </section>
  `;
}

function renderStorySection() {
  return `
    <section class="section">
      <div class="section-header"><div><h3>Story</h3><p>Use concise story beats that support visual design decisions.</p></div></div>
      <div class="field-grid">
        ${textField("story.origin", "Origin")}
        ${textField("story.goal", "Goal")}
        ${textField("story.conflict", "Conflict")}
        ${textField("story.relationships", "Relationships")}
      </div>
    </section>
  `;
}

function renderStyleSection() {
  return `
    <section class="section">
      <div class="section-header"><div><h3>Style direction</h3><p>Frame references as transformed inspiration and preserve originality.</p></div></div>
      <div class="field-grid">
        ${selectField("style.artStyle", "Art style", DATA.styles)}
        ${inputField("style.mood", "Mood")}
        ${inputField("style.camera", "Camera / framing")}
        ${inputField("style.generator", "Generator target")}
      </div>
      <div style="margin-top: 16px;">${textField("style.originality", "Originality rule")}</div>
    </section>
  `;
}

function renderReferenceCards() {
  return `
    <div class="reference-grid">
      ${state.references
        .map(
          (ref) => `
            <article class="reference-card">
              <img class="reference-image" src="${ref.dataUrl}" alt="${escapeHtml(ref.name)}" />
              <div class="reference-body">
                <div>
                  <strong>${escapeHtml(ref.name)}</strong>
                  <p class="help-text">Label what this reference contributes. These labels are included in the prompt as transformed inspiration.</p>
                </div>
                <div class="palette-row">
                  ${(ref.palette || []).map((color) => `<span class="swatch" title="${color}" style="background:${color}"></span>`).join("")}
                </div>
                <div class="checkbox-grid">
                  ${DATA.referenceUses
                    .map(
                      (use) => `
                        <label class="checkbox-row">
                          <input type="checkbox" data-action="reference-use" data-ref="${ref.id}" data-use="${use}" ${ref.uses?.includes(use) ? "checked" : ""} />
                          ${use}
                        </label>
                      `
                    )
                    .join("")}
                </div>
                <div class="field">
                  <label class="field-label">Observation notes</label>
                  <textarea data-action="reference-note" data-ref="${ref.id}" placeholder="Example: borrow the asymmetrical coat silhouette, not the character identity.">${escapeHtml(ref.notes || "")}</textarea>
                </div>
                <div class="field-grid">
                  <div class="field">
                    <label class="field-label">Strength</label>
                    <select data-action="reference-strength" data-ref="${ref.id}">
                      ${["subtle", "moderate", "strong"].map((value) => `<option value="${value}" ${ref.strength === value ? "selected" : ""}>${value}</option>`).join("")}
                    </select>
                  </div>
                  <div class="field">
                    <label class="field-label">Originality guard</label>
                    <input data-action="reference-guard" data-ref="${ref.id}" value="${escapeHtml(ref.guard || "transform into an original design")}" />
                  </div>
                </div>
                <button class="danger-button" data-action="delete-reference" data-ref="${ref.id}">Remove reference</button>
              </div>
            </article>
          `
        )
        .join("")}
    </div>
  `;
}

function renderPreview() {
  return `
    <aside class="preview" aria-label="Live character preview">
      <div class="preview-block">
        <p class="section-kicker">Live brief</p>
        <h2>${escapeHtml(state.identity.name)}</h2>
        <dl>
          ${getBriefRows()
            .map((row) => `<div class="brief-row"><dt>${escapeHtml(row[0])}</dt><dd>${escapeHtml(row[1])}</dd></div>`)
            .join("")}
        </dl>
      </div>
      <div class="preview-block">
        <p class="section-kicker">Prompt</p>
        <div class="prompt-box small">${escapeHtml(buildPrompt())}</div>
      </div>
      <div class="preview-block">
        <p class="section-kicker">Suggestions</p>
        <ul class="suggestion-list">
          ${getSuggestions().map((item) => `<li>${escapeHtml(item)}</li>`).join("")}
        </ul>
      </div>
    </aside>
  `;
}

function getBriefRows() {
  return [
    ["Role", `${state.identity.role}; ${state.identity.archetype}`],
    ["Species", `${state.species.type}; ${state.species.anatomy}`],
    ["Build", `${state.body.height}, ${state.body.build}`],
    ["Wardrobe", `${list(state.wardrobe.clothing)}; ${list(state.wardrobe.materials)}`],
    ["Personality", `${list(state.personality.traits)}; flaw: ${list(state.personality.flaws)}`],
    ["World", `${state.world.setting}; ${state.world.faction}`],
    ["Style", `${state.style.artStyle}; ${state.style.mood}`]
  ];
}

function getReferencePromptLines() {
  if (!state.references.length) return [];
  return state.references.map((ref, index) => {
    const uses = ref.uses?.length ? ref.uses.join(", ") : "general inspiration only";
    const palette = ref.palette?.length ? `palette swatches ${ref.palette.join(", ")}` : "no extracted palette";
    const notes = ref.notes ? `notes: ${ref.notes}` : "no notes";
    const guard = ref.guard || "transform into an original design";
    return `Reference ${index + 1} (${ref.name}): use for ${uses}; strength ${ref.strength || "moderate"}; ${palette}; ${notes}; guardrail: ${guard}.`;
  });
}

function buildPrompt() {
  const lines = [
    `Create an original character design of ${state.identity.name}, ${state.identity.pronouns}, ${state.identity.age}, ${state.identity.role}.`,
    `Core concept: ${state.identity.oneLine}`,
    `Archetype and world: ${state.identity.archetype} in a ${state.world.setting}; faction: ${state.world.faction}; occupation: ${state.world.occupation}; stakes: ${state.world.stakes}.`,
    `Species/anatomy: ${state.species.type}; ${state.species.anatomy}; distinctness rule: ${state.species.distinctness}.`,
    `Body: ${state.body.height}, ${state.body.build} build, ${state.body.face}; marks: ${state.body.marks || "none specified"}; posture: ${state.body.posture}.`,
    `Wardrobe: ${list(state.wardrobe.clothing)}; materials: ${list(state.wardrobe.materials)}; accessories: ${list(state.wardrobe.accessories)}; color notes: ${state.wardrobe.colorNotes}.`,
    `Personality shown through design: ${list(state.personality.traits)}; flaws: ${list(state.personality.flaws)}; habits: ${state.personality.habits}; voice: ${state.personality.voice}.`,
    `Story cues: origin: ${state.story.origin}; goal: ${state.story.goal}; conflict: ${state.story.conflict}; relationships: ${state.story.relationships}.`,
    `Style: ${state.style.artStyle}; mood: ${state.style.mood}; camera: ${state.style.camera}; generator target: ${state.style.generator}.`,
    state.style.originality
  ];

  const referenceLines = getReferencePromptLines();
  if (referenceLines.length) {
    lines.push("Reference transformation plan:", ...referenceLines);
  }

  lines.push("Avoid copyrighted character replication, logos, text artifacts, extra limbs unless specified, and inconsistent anatomy.");

  return lines.filter(Boolean).join("\n");
}

function buildSheet() {
  const referenceLines = state.references.length
    ? state.references
        .map((ref, index) => `- ${index + 1}. ${ref.name}: uses ${list(ref.uses)}; strength ${ref.strength}; notes: ${ref.notes || "none"}`)
        .join("\n")
    : "- None";

  return `# ${state.identity.name}\n\n## Brief\n${state.identity.oneLine}\n\n## Identity\n- Pronouns: ${state.identity.pronouns}\n- Age impression: ${state.identity.age}\n- Role: ${state.identity.role}\n- Archetype: ${state.identity.archetype}\n\n## Body and Species\n- Species: ${state.species.type}\n- Anatomy: ${state.species.anatomy}\n- Distinctness: ${state.species.distinctness}\n- Build: ${state.body.height}, ${state.body.build}\n- Face: ${state.body.face}\n- Marks: ${state.body.marks || "None specified"}\n- Posture: ${state.body.posture}\n\n## Wardrobe\n- Clothing: ${list(state.wardrobe.clothing)}\n- Materials: ${list(state.wardrobe.materials)}\n- Accessories: ${list(state.wardrobe.accessories)}\n- Color notes: ${state.wardrobe.colorNotes}\n\n## World\n- Setting: ${state.world.setting}\n- Faction: ${state.world.faction}\n- Occupation: ${state.world.occupation}\n- Stakes: ${state.world.stakes}\n\n## Personality\n- Traits: ${list(state.personality.traits)}\n- Flaws: ${list(state.personality.flaws)}\n- Habits: ${state.personality.habits}\n- Voice: ${state.personality.voice}\n\n## Story\n- Origin: ${state.story.origin}\n- Goal: ${state.story.goal}\n- Conflict: ${state.story.conflict}\n- Relationships: ${state.story.relationships}\n\n## Style Direction\n- Art style: ${state.style.artStyle}\n- Mood: ${state.style.mood}\n- Camera: ${state.style.camera}\n- Generator target: ${state.style.generator}\n- Originality rule: ${state.style.originality}\n\n## Semantic References\n${referenceLines}\n\n## Generator Prompt\n${buildPrompt()}\n`;
}

function getSuggestions() {
  const suggestions = [];
  if (!state.body.marks) suggestions.push("Add a scar, tattoo, pattern, or asymmetry to make the silhouette more memorable.");
  if (!state.references.length) suggestions.push("Upload at least one reference and label what should be borrowed semantically.");
  if (state.wardrobe.accessories.length < 2) suggestions.push("Add one more accessory to communicate role or history.");
  if (!state.world.faction || state.world.faction === "No fixed faction") suggestions.push("Give the character a faction, rival group, or former allegiance.");
  if (!state.api.imageGenerationAvailable) suggestions.push("Configure OPENAI_API_KEY to enable image generation; prompt export is already available.");
  return suggestions.slice(0, 5);
}

function handleInput(event) {
  const target = event.target;
  if (target.dataset.path) {
    setPath(target.dataset.path, target.value);
  }

  const refId = target.dataset.ref;
  if (target.dataset.action === "reference-note") updateRef(refId, { notes: target.value });
  if (target.dataset.action === "reference-guard") updateRef(refId, { guard: target.value });
}

function handleChange(event) {
  const target = event.target;
  if (target.dataset.path) {
    setPath(target.dataset.path, target.value);
  }

  if (target.dataset.action === "import-json") importJson(target.files?.[0]);
  if (target.dataset.action === "upload-references") handleFiles(target.files);
  if (target.dataset.action === "reference-strength") updateRef(target.dataset.ref, { strength: target.value });
  if (target.dataset.action === "reference-use") toggleReferenceUse(target.dataset.ref, target.dataset.use, target.checked);
}

function handleClick(event) {
  const button = event.target.closest("button");
  if (!button) return;

  const action = button.dataset.action;
  if (!action) return;

  if (action === "set-mode") setPath("mode", button.dataset.mode);
  if (action === "apply-blueprint") applyBlueprint(button.dataset.blueprint);
  if (action === "chip") toggleChip(button.dataset.path, button.dataset.value, button.dataset.multiple === "true");
  if (action === "surprise") surprise();
  if (action === "reset") resetState();
  if (action === "copy-prompt") copyText(buildPrompt());
  if (action === "copy-sheet") copyText(buildSheet());
  if (action === "download-sheet") downloadFile(`${slug(state.identity.name)}.md`, buildSheet(), "text/markdown");
  if (action === "export-json") downloadFile(`${slug(state.identity.name)}.json`, JSON.stringify(state, null, 2), "application/json");
  if (action === "parse-freeform") parseFreeform();
  if (action === "expand-freeform") expandFreeform();
  if (action === "delete-reference") deleteReference(button.dataset.ref);
  if (action === "generate-image") generateImage();
}

function toggleChip(path, value, multiple) {
  if (!multiple) {
    setPath(path, value);
    return;
  }
  const current = new Set(getPath(path) || []);
  current.has(value) ? current.delete(value) : current.add(value);
  setPath(path, [...current]);
}

function applyBlueprint(id) {
  const blueprint = BLUEPRINTS.find((item) => item.id === id);
  if (!blueprint) return;
  state = mergeDeep(state, blueprint.patch);
  saveState();
  render();
}

function surprise() {
  const pick = (items) => items[Math.floor(Math.random() * items.length)];
  const blueprint = pick(BLUEPRINTS);
  state = mergeDeep(state, blueprint.patch);
  state.identity.name = ["Veyra", "Kade", "Nox", "Mira", "Sable", "Thorne", "Ivo", "Nyx"][Math.floor(Math.random() * 8)];
  state.body.build = pick(DATA.builds);
  state.species.type = pick(DATA.species.filter((item) => item !== "Custom"));
  state.world.setting = pick(DATA.settings);
  state.style.artStyle = pick(DATA.styles);
  state.personality.traits = [pick(DATA.personalities), pick(DATA.personalities)].filter((value, index, array) => array.indexOf(value) === index);
  saveState();
  render();
}

function resetState() {
  if (!confirm("Reset the current character design?")) return;
  state = clone(DEFAULT_STATE);
  saveState();
  checkApiStatus();
  render();
}

function parseFreeform() {
  const text = state.freeform.toLowerCase();
  const patch = {};

  DATA.species.forEach((item) => {
    if (text.includes(item.toLowerCase())) patch.species = { ...(patch.species || {}), type: item };
  });
  DATA.builds.forEach((item) => {
    if (text.includes(item)) patch.body = { ...(patch.body || {}), build: item };
  });
  DATA.settings.forEach((item) => {
    if (text.includes(item)) patch.world = { ...(patch.world || {}), setting: item };
  });
  DATA.clothing.forEach((item) => {
    if (text.includes(item)) patch.wardrobe = { ...(patch.wardrobe || {}), clothing: unique([...(patch.wardrobe?.clothing || state.wardrobe.clothing), item]) };
  });
  DATA.accessories.forEach((item) => {
    if (text.includes(item)) patch.wardrobe = { ...(patch.wardrobe || {}), accessories: unique([...(patch.wardrobe?.accessories || state.wardrobe.accessories), item]) };
  });
  DATA.personalities.forEach((item) => {
    if (text.includes(item)) patch.personality = { ...(patch.personality || {}), traits: unique([...(patch.personality?.traits || state.personality.traits), item]) };
  });

  if (text.includes("neon")) patch.style = { ...(patch.style || {}), mood: "neon-lit, high contrast" };
  if (text.includes("royal") || text.includes("regent")) patch.identity = { ...(patch.identity || {}), archetype: "royal" };
  if (text.includes("courier")) patch.identity = { ...(patch.identity || {}), role: "Courier" };
  if (text.includes("hunter")) patch.identity = { ...(patch.identity || {}), archetype: "hunter" };

  state = mergeDeep(state, patch);
  saveState();
  render();
}

function expandFreeform() {
  const expanded = [
    state.freeform.trim(),
    `Core: ${state.identity.name} is ${state.identity.oneLine}`,
    `Visual: ${state.species.type}, ${state.body.build} build, ${list(state.wardrobe.clothing)}, ${list(state.wardrobe.accessories)}.`,
    `Story: ${state.story.goal} Conflict: ${state.story.conflict}.`,
    `Style: ${state.style.artStyle}, ${state.style.mood}.`
  ]
    .filter(Boolean)
    .join("\n");
  setPath("freeform", expanded);
}

function unique(values) {
  return [...new Set(values.filter(Boolean))];
}

async function handleFiles(fileList) {
  const files = [...(fileList || [])].filter((file) => file.type.startsWith("image/"));
  const refs = [];

  for (const file of files) {
    const dataUrl = await readAsDataUrl(file);
    const palette = await extractPalette(dataUrl).catch(() => []);
    refs.push({
      id: uid(),
      name: file.name,
      dataUrl,
      palette,
      uses: palette.length ? ["palette"] : [],
      notes: "",
      strength: "moderate",
      guard: "transform into an original design"
    });
  }

  state.references = [...state.references, ...refs];
  saveState();
  render();
}

function readAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function extractPalette(dataUrl) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => {
      const canvas = document.createElement("canvas");
      const size = 80;
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext("2d", { willReadFrequently: true });
      ctx.drawImage(image, 0, 0, size, size);
      const { data } = ctx.getImageData(0, 0, size, size);
      const buckets = new Map();

      for (let i = 0; i < data.length; i += 16) {
        const alpha = data[i + 3];
        if (alpha < 128) continue;
        const r = Math.round(data[i] / 32) * 32;
        const g = Math.round(data[i + 1] / 32) * 32;
        const b = Math.round(data[i + 2] / 32) * 32;
        const key = `${Math.min(r, 255)},${Math.min(g, 255)},${Math.min(b, 255)}`;
        buckets.set(key, (buckets.get(key) || 0) + 1);
      }

      const colors = [...buckets.entries()]
        .sort((a, b) => b[1] - a[1])
        .slice(0, 6)
        .map(([key]) => {
          const [r, g, b] = key.split(",").map(Number);
          return rgbToHex(r, g, b);
        });

      resolve(colors);
    };
    image.onerror = reject;
    image.src = dataUrl;
  });
}

function rgbToHex(r, g, b) {
  return `#${[r, g, b].map((value) => value.toString(16).padStart(2, "0")).join("")}`;
}

function updateRef(id, patch) {
  state.references = state.references.map((ref) => (ref.id === id ? { ...ref, ...patch } : ref));
  saveState();
}

function toggleReferenceUse(id, use, enabled) {
  state.references = state.references.map((ref) => {
    if (ref.id !== id) return ref;
    const uses = new Set(ref.uses || []);
    enabled ? uses.add(use) : uses.delete(use);
    return { ...ref, uses: [...uses] };
  });
  saveState();
  render();
}

function deleteReference(id) {
  state.references = state.references.filter((ref) => ref.id !== id);
  saveState();
  render();
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const textarea = document.createElement("textarea");
    textarea.value = text;
    document.body.append(textarea);
    textarea.select();
    document.execCommand("copy");
    textarea.remove();
  }
}

function downloadFile(filename, content, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function importJson(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const imported = JSON.parse(reader.result);
      state = mergeDeep(clone(DEFAULT_STATE), imported);
      saveState();
      checkApiStatus();
      render();
    } catch {
      alert("Could not import JSON. Check that the file is valid Character Atelier data.");
    }
  };
  reader.readAsText(file);
}

function slug(value) {
  return String(value || "character")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "") || "character";
}

async function checkApiStatus() {
  try {
    const response = await fetch("/api/health");
    const data = await response.json();
    state.api.checked = true;
    state.api.imageGenerationAvailable = Boolean(data.imageGenerationAvailable);
    state.api.model = data.model || "gpt-image-2";
  } catch {
    state.api.checked = true;
    state.api.imageGenerationAvailable = false;
    state.api.model = "gpt-image-2";
  }
  saveState();
  render();
}

async function generateImage() {
  state.imageStatus = "loading";
  state.generatedError = "";
  saveState();
  render();

  try {
    const response = await fetch("/api/generate-image", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        prompt: buildPrompt(),
        size: state.promptOptions.size,
        quality: state.promptOptions.quality,
        outputFormat: state.promptOptions.outputFormat
      })
    });
    const data = await response.json();

    if (!response.ok || !data.ok) throw new Error(data.error || "Image generation failed.");

    state.generatedImage = data.image;
    state.imageStatus = "done";
  } catch (error) {
    state.generatedError = error.message;
    state.imageStatus = "error";
  }

  saveState();
  render();
}

render();
checkApiStatus();
