const ALLOWED_SIZES = new Set(["1024x1024", "1024x1536", "1536x1024", "auto"]);
const ALLOWED_QUALITY = new Set(["low", "medium", "high", "auto"]);
const ALLOWED_FORMATS = new Set(["png", "jpeg", "webp"]);

function validateImageRequest(body = {}) {
  const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
  const size = typeof body.size === "string" ? body.size : "1024x1024";
  const quality = typeof body.quality === "string" ? body.quality : "medium";
  const outputFormat = typeof body.outputFormat === "string" ? body.outputFormat : "png";

  if (!prompt) throw Object.assign(new Error("Prompt is required."), { statusCode: 400 });
  if (prompt.length > 8000) {
    throw Object.assign(new Error("Prompt must be 8000 characters or fewer."), { statusCode: 400 });
  }
  if (!ALLOWED_SIZES.has(size)) throw Object.assign(new Error("Unsupported image size."), { statusCode: 400 });
  if (!ALLOWED_QUALITY.has(quality)) throw Object.assign(new Error("Unsupported image quality."), { statusCode: 400 });
  if (!ALLOWED_FORMATS.has(outputFormat)) throw Object.assign(new Error("Unsupported output format."), { statusCode: 400 });

  return { prompt, size, quality, outputFormat };
}

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.status(405).json({ ok: false, error: "Method not allowed." });
    return;
  }

  if (!process.env.OPENAI_API_KEY) {
    res.status(503).json({
      ok: false,
      error: "OPENAI_API_KEY is not configured. Copy or export the prompt instead."
    });
    return;
  }

  try {
    const { prompt, size, quality, outputFormat } = validateImageRequest(req.body);
    const response = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-image-2",
        prompt,
        size,
        quality,
        output_format: outputFormat
      })
    });

    const payload = await response.json().catch(() => ({}));

    if (!response.ok) {
      res.status(response.status).json({
        ok: false,
        error: payload?.error?.message || "Image generation failed."
      });
      return;
    }

    const b64 = payload?.data?.[0]?.b64_json;
    if (!b64) {
      res.status(502).json({ ok: false, error: "Image response did not include image data." });
      return;
    }

    res.status(200).json({
      ok: true,
      image: `data:image/${outputFormat};base64,${b64}`
    });
  } catch (error) {
    res.status(error.statusCode || 500).json({
      ok: false,
      error: error.message || "Unexpected image-generation error."
    });
  }
}
